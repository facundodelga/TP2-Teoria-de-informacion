# TPI 2: Facundo Delgado, Wendy Zamora
#Desarrollar un programa que pueda ser ejecutado por consola del siguiente modo:

#tpi2 filename.txt

#Donde:

#tpi2 es el programa ejecutable
#filename.txt es un archivo de texto ASCII
#El programa debe realizar las siguientes acciones:

#Obtener las probabilidades de las palabras (separadas por espacios) contenidas en el archivo filename.txt.
#Identificar el alfabeto código que compone las palabras.
#Calcular la entropía de la fuente y la longitud media del código.
#Comprobar si la codificación cumple las inecuaciones de Kraft y McMillan.
#Determinar si el código es instantáneo y/o compacto.
import sys
import math
class AnalisisCodigos:
    def __init__(self,filename):
        self.filename=filename
        self.dicProbPalabras={}
        self.alfabetoCodigo=set()
        self.entropiaFuente=0
        self.longitudMedia=0
    
    def leeArchivo(self):
        with open(self.filename,'rt',encoding="ascii") as f:
            file=f.read()
            # Se introduce el archivo en un set, el cual toma los caracteres en unicidad y sin repeticion
            # lo cual resulta en el alfabeto codigo que compone a las palabras
            self.alfabetoCodigo=set(letra for letra in file if letra!=' ')
            # Se suben todas las palabras del archivo separadas por un espacio a una lista de palabras
            palabras=file.split()
        
        # Inicializa las claves en el diccionario
        for palabra in palabras:
            if palabra not in self.dicProbPalabras:
                self.dicProbPalabras[palabra] = 0
        #Se obtienen los contadores de cada palabra en el diccionario, luego se suma el total de palabras
        # y se dividen los contadores de cada una por el total para obtener la probabilidad de cada palabra
        for x in palabras:
            self.dicProbPalabras[x]+=1
        sum=0
        for key in self.dicProbPalabras:
            sum+=self.dicProbPalabras[key]
        for key in self.dicProbPalabras:
            self.dicProbPalabras[key]/=sum
        return 0

    def imprimeAlfabetoFuenteYProb(self):
        print("Las palabras y sus probabilidades de encontrarlas en el archivo son:")
        print(self.dicProbPalabras)
    
    def imprimeAlfabetoCodigo(self):
        print("El alfabeto codigo del archivo ingresado es:")
        print(self.alfabetoCodigo)
    
    def calculoEntropiaFuente(self):
        #Se calcula la cantidad de simbolos en el codigo para saber la base
        r=len(self.alfabetoCodigo)
        #Se calcula la entropia de la fuente ingresada en el archivo 
        self.entropiaFuente=sum(self.dicProbPalabras[key]*math.log(1/self.dicProbPalabras[key],r) for key in self.dicProbPalabras)
        print("La entropia en base {base} de la fuente del archivo es: {entropia}".format(base=r,entropia=self.entropiaFuente))

    def calculoLongitudMediaCodigo(self):
        #Se calcula la longitud media del codigo del archivo
        self.longitudMedia=sum(probabilidad*len(key) for key,probabilidad in self.dicProbPalabras.items())
        print("La longitud media del codigo en el archivo es: {0}".format(self.longitudMedia))

    def calculaKraftMcMillan(self):
        r=len(self.alfabetoCodigo)
        return sum(r**(-len(key)) for key in self.dicProbPalabras)

    def esInstantaneo(self):
        # Se crea un arbol de prefijos (Arbol) que representa las palabras del codigo
        arbol={}
        # Se itera sobre cada palabra en el codigo y construimos el arbol de prefijos
        for secuencia in self.dicProbPalabras:
            nodo=arbol
            #Simbolo a simbolo
            for simbolo in secuencia:
                if simbolo not in nodo:
                    nodo[simbolo]={}
                nodo=nodo[simbolo]
                #Si se llega a un nodo que marca el final de una secuencia de simbolos
                #ya existente se retorna False
                if '*' in nodo:
                    return False
            # Marca el final de la palabra
            nodo['*']={}
        return True

    def esCompacto(self):
        return self.entropiaFuente>=self.longitudMedia
    
def main():
    filename=sys.argv[1]
    print("Analisis para el archivo: {0}".format(filename))
    print("Integrantes: Wendy Zamora, Facundo Delgado, Pedro Arias :)")
    TPI=AnalisisCodigos(filename)
    TPI.leeArchivo()
    TPI.imprimeAlfabetoFuenteYProb()
    TPI.imprimeAlfabetoCodigo()
    TPI.calculoEntropiaFuente()
    TPI.calculoLongitudMediaCodigo()
    KraftMcMillan=TPI.calculaKraftMcMillan()
    if(KraftMcMillan<=1):
        print("El codigo ingresado cumple con las ecuaciones de Kraft y McMillan ({0}<=1)".format(KraftMcMillan))
        if(TPI.esInstantaneo()):
            print("El codigo ingresado es instantaneo")
            if(TPI.esCompacto()):
                print("El codigo ingresado es compacto")
            else:
                print("El codigo ingresado no es compacto")
        else:
            print("El codigo ingresado no es instantaneo")
    else:
        print("El codigo ingresado no cumple con las ecuaciones de Kraft y McMillan ({0}>1)".format(KraftMcMillan))


if __name__ == '__main__':
    main()

