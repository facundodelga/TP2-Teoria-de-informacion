# TPI-2-Teoria-de-Informacion
 
